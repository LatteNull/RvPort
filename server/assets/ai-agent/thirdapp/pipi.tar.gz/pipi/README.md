# pipi — 在启动 pi 时显式传入模型供应商 URL

一个最小侵入的方案：让 pi 像 codex / claude-code 等其它 agent 一样，在启动时
通过命令行指定模型供应商的 URL 和模型参数。

由两部分组成：

| 文件 | 作用 | 安装位置 |
|---|---|---|
| `pipi` | shell wrapper，解析命令行参数 → 环境变量 → exec pi | 任意 PATH 目录（如 `~/.local/bin/pipi`） |
| `url-provider.ts` | pi 扩展，读环境变量 → `pi.registerProvider()` 内存注册 | `~/.pi/agent/extensions/url-provider.ts` |

**关键特性**：扩展是**纯内存注册**，完全不修改 `~/.pi/agent/models.json`。每次
启动只在当前进程里临时新增一个名为 `cli-url` 的 provider，进程结束即消失。多个
终端同时用不同 URL 互不干扰。

---

## 一、安装

```bash
# 1) wrapper 脚本放到 PATH
chmod +x pipi
cp pipi ~/.local/bin/pipi        # 或其它在 $PATH 里的目录

# 2) 扩展放到 pi 的全局扩展目录（自动发现，无需 -e / 无需 /reload）
mkdir ~/.pi/agent/extensions
cp url-provider.ts ~/.pi/agent/extensions/url-provider.ts



pipi --base-url https://wxai-rch.zx.zte.com.cn/v1 --api-key aione_123 --model-id glm --reasoning --context-window 200000 --max-tokens 200000 --mode json -p "你好，你是谁"

pipi --base-url https://wxai-rch.zx.zte.com.cn/v1 --api-key aione_123 --model-id glm --reasoning --context-window 200000 --max-tokens 200000 --mode json -c -p "继续"




```

验证安装：
```bash
pipi --help          # 看到 wrapper 帮助
pi --list-models     # 普通 pi 启动，扩展读不到 PI_BASE_URL 自动 no-op，行为不变
```

---

## 二、使用

### 参数

**必填**（wrapper 解析）：
- `--base-url <URL>` — 供应商端点
- `--model-id <ID>` — 模型 ID（发给 API 的 model 字段）

**可选**（wrapper 解析）：
- `--api <TYPE>` — API 类型，默认 `openai-completions`
  可选：`openai-completions` | `anthropic-messages` | `openai-responses` | `google-generative-ai` 等
- `--api-key <KEY>` — API key（**建议必填**，否则模型在 `/model` 列表里不可见）
  对 keyless 本地服务（Ollama、LM Studio）随便传一个非空字符串即可（如 `--api-key ollama`）
- `--model-name <NAME>` — 显示名，默认同 `--model-id`
- `--context-window <N>` — 上下文窗口（token），默认 `128000`
- `--max-tokens <N>` — 单次最大输出，默认 `16384`
- `--reasoning` — 启用思考/推理支持（默认关）
- `--image` — 启用图像输入（默认仅文本）
- `--model-json '<JSON>'` — 高级覆盖，一个 JSON 对象，可覆盖任意模型字段
  例：`'{"compat":{"supportsDeveloperRole":false},"cost":{"input":3,"output":15,"cacheRead":0.3,"cacheWrite":3.75}}'`

**透传**：其余参数（`-p` / `--print`、`--verbose`、prompt 文本、`@file.md` 等）原样
转发给 pi。

### 字段与 pi 内部默认值对照

（实测自 pi 的 `provider-composer.js`）

| 字段 | 默认值 | 说明 |
|---|---|---|
| `api` | `openai-completions` | |
| `contextWindow` | `128000` | token 数 |
| `maxTokens` | `16384` | 单次输出上限 |
| `reasoning` | `false` | |
| `input` | `["text"]` | `--image` 后变 `["text","image"]` |
| `cost` | 全 0 | 仅影响 `/usage` 费用统计 |
| `compat` | 省略 | OpenAI 兼容服务端怪癖，用 `--model-json` 设置 |

### 示例

```bash
# 1) 一次性 print 模式打本地 Ollama
pipi --base-url http://localhost:11434/v1 --model-id llama3.1:8b \
     --api-key ollama -p "say hi"

# 2) 交互式，200k 上下文 + 思考模型
pipi --base-url https://api.example.com/v1 --model-id glm-4 \
     --api-key "$KEY" --context-window 200000 --reasoning

# 3) OpenAI 兼容但不支持 developer role 的服务端
pipi --base-url http://localhost:8080/v1 --model-id my-model \
     --api-key dummy \
     --model-json '{"compat":{"supportsDeveloperRole":false,"supportsReasoningEffort":false}}'

# 4) 带初始 prompt 进入交互
pipi --base-url http://localhost:11434/v1 --model-id qwen2.5-coder:7b \
     --api-key ollama --context-window 32768 "帮我写个快速排序"
```

---

## 三、如何确认传入内容被 pi 使用了

四层验证手段，按需取用：

### 1) 列表确认（最快）
```bash
pipi --base-url http://... --model-id myglm --context-window 200000 --reasoning \
     --api-key dummy --list-models
```
输出会显示 `cli-url` provider 与你传入的 `context` / `max-out` / `thinking` / `images`
列值，直接对得上即说明已注册。

### 2) 扩展自检日志
wrapper 启动时扩展会写一行 stderr：
```
[url-provider] registered cli-url/myglm ctx=200000 max=16384 api=openai-completions ...
```
配合 `--verbose` 可看到 pi 把它纳入模型目录的过程。

### 3) 交互模式 `/model`
进入 pi 后输入 `/model`，列表里能看到 `cli-url/myglm`。

### 4) 端到端发一次请求
```bash
pipi ... -p "你好"
```
正常返回响应 → URL / api-key / api 类型全链路打通。失败则错误信息会明确指出
是 URL 不通还是 API 类型不匹配。

---

## 四、设计要点

1. **为什么用扩展 + wrapper 两层？**
   pi 没有 `--base-url` 这个 CLI 选项，模型 URL 的唯一入口是 `models.json`（会被
   改文件，并发不安全）或扩展的 `pi.registerProvider()`（纯内存）。本方案走后者，
   干净、可并发、零配置污染。

2. **为什么 wrapper 只能把参数翻译成环境变量？**
   扩展和 pi 在同一进程，扩展是 TS 模块，拿不到 wrapper 解析的命令行参数，只能
   通过 `process.env` 读。所以 wrapper 负责解析 → 导出 `PI_BASE_*` → exec pi。

3. **为什么 `--api-key` 几乎必填？**
   pi 把模型视为需要 auth 才出现在 `/model` 列表里。扩展注册时若 apiKey 解析为
   空，模型虽然进了内存但用户看不到，会以为没生效。

4. **普通 `pi` 不受影响**
   没有 `PI_BASE_URL` 时扩展直接 return（no-op），开销可忽略。

---

## 五、已知限制

- 同时只支持一个 URL（provider 名固定为 `cli-url`）。要在一次会话里切多个 URL，
  用 pi 原生的 `/model` 切换到其它 provider。
- `--model-json` 在命令行写 JSON 需要引号转义，复杂场景建议写进 shell 变量再传。
- 扩展总是被 pi 自动加载；如需临时禁用，重命名或删掉 `~/.pi/agent/extensions/url-provider.ts`。
